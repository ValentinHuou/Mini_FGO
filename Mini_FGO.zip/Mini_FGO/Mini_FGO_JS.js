/* ================= DATA ================= */

const characters = [
{ id:999, name:"Solomon (True Origin)", rarity:9 },

{ id:990, name:"Void SHIKI", rarity:8 },
{ id:991, name:"ORT", rarity:8 },
{ id:992, name:"Archetype: Earth", rarity:8 },

{ id:900, name:"Unsealed Artoria", rarity:7 },
{ id:901, name:"Alive Gilgamesh", rarity:7 },
{ id:902, name:"Moon Cell", rarity:7 },
{ id:903, name:"Sefar", rarity:7 },

/* ================= ★★★★★★ ================= */
{ id:800, name:"U-Olga Marie", rarity:6, type:"divine" },
{ id:801, name:"Gaïa", rarity:6, type:"divine" },
{ id:802, name:"Alaya", rarity:6, type:"divine" },
{ id:803, name:"Tiamat", rarity:6, type:"divine" },
{ id:804, name:"Goetia", rarity:6, type:"divine" },
{ id:805, name:"Kiara Sessyoin", rarity:6, type:"divine" },
{ id:806, name:"CCC Gilgamesh", rarity:6, type:"divine" },
{ id:807, name:"BB (Moon Cancer)", rarity:6, type:"divine" },
{ id:808, name:"Space Ereshkigal", rarity:6, type:"divine" },
{ id:809, name:"Space Ishtar", rarity:6, type:"divine" },
{ id:810, name:"Kama (Beast)", rarity:6, type:"divine" },
{ id:811, name:"Zelretch", rarity:6, type:"divine" },

/* ================= ★★★★★ ================= */
{ id:100, name:"Artoria Pendragon", rarity:5, type:"normal" },
{ id:101, name:"Gilgamesh", rarity:5, type:"normal" },
{ id:102, name:"Jeanne d’Arc", rarity:5, type:"normal" },
{ id:103, name:"Ishtar", rarity:5, type:"normal" },
{ id:104, name:"Ereshkigal", rarity:5, type:"normal" },
{ id:105, name:"Merlin", rarity:5, type:"normal" },
{ id:106, name:"Scáthach", rarity:5, type:"normal" },
{ id:107, name:"Karna", rarity:5, type:"normal" },
{ id:108, name:"Ozymandias", rarity:5, type:"normal" },
{ id:109, name:"Musashi", rarity:5, type:"normal" },
{ id:110, name:"Oberon", rarity:5, type:"normal" },
{ id:111, name:"Morgan Le Fay", rarity:5, type:"normal" },
{ id:112, name:"First Hassan", rarity:5, type:"normal" },
{ id:113, name:"Altera", rarity:5, type:"normal" },
{ id:114, name:"Tamamo no Mae", rarity:5, type:"normal" },
{ id:115, name:"Mordred", rarity:5, type:"normal" },
{ id:116, name:"Saber Venus", rarity:5, type:"normal" },
{ id:117, name:"Arjuna", rarity:5, type:"normal" },

/* ================= ★★★★ ================= */
{ id:200, name:"Emiya", rarity:4, type:"normal" },
{ id:201, name:"Heracles", rarity:4, type:"normal" },
{ id:202, name:"Atalanta", rarity:4, type:"normal" },
{ id:203, name:"Siegfried", rarity:4, type:"normal" },
{ id:204, name:"Medusa (Rider)", rarity:4, type:"normal" },
{ id:205, name:"Nero Claudius", rarity:4, type:"normal" },
{ id:206, name:"Lancelot (Berserker)", rarity:4, type:"normal" },
{ id:207, name:"Gawain", rarity:4, type:"normal" },
{ id:208, name:"Elizabeth Bathory", rarity:4, type:"normal" },
{ id:209, name:"Astolfo", rarity:4, type:"normal" },
{ id:210, name:"Okita Souji", rarity:4, type:"normal" },
{ id:211, name:"Nitocris", rarity:4, type:"normal" },

/* ================= ★★★ ================= */
{ id:300, name:"Cu Chulainn", rarity:3, type:"normal" },
{ id:301, name:"Ushiwakamaru", rarity:3, type:"normal" },
{ id:302, name:"Robin Hood", rarity:3, type:"normal" },
{ id:303, name:"Leonidas I", rarity:3, type:"normal" },
{ id:304, name:"Hassan of the Cursed Arm", rarity:3, type:"normal" },
{ id:305, name:"Medusa (Lancer)", rarity:3, type:"normal" },
{ id:306, name:"Bedivere", rarity:3, type:"normal" },
{ id:307, name:"Euryale", rarity:3, type:"normal" },
{ id:308, name:"David", rarity:3, type:"normal" },
{ id:309, name:"Jaguar Warrior", rarity:3, type:"normal" },
{ id:310, name:"Boudica", rarity:3, type:"normal" },
{ id:311, name:"Gareth", rarity:3, type:"normal" },
{ id:312, name:"Mandricardo", rarity:3, type:"normal" },
{ id:313, name:"Paris", rarity:3, type:"normal" },

/* ================= ★★ ================= */
{ id:400, name:"Arash", rarity:2, type:"normal" },
{ id:401, name:"Leonidas", rarity:2, type:"normal" },
{ id:402, name:"Mozart", rarity:2, type:"normal" },
{ id:403, name:"Shakespeare", rarity:2, type:"normal" },
{ id:404, name:"Spartacus", rarity:2, type:"normal" },
{ id:405, name:"Gilles de Rais", rarity:2, type:"normal" },
{ id:406, name:"Salome", rarity:2, type:"normal" },
{ id:407, name:"Paul Bunyan", rarity:2, type:"normal" },
{ id:408, name:"Asterios", rarity:2, type:"normal" },
{ id:409, name:"Chen Gong", rarity:2, type:"normal" },
{ id:410, name:"Charlotte Corday", rarity:2, type:"normal" },
{ id:411, name:"Bartholomew Roberts", rarity:2, type:"normal" },
{ id:412, name:"Jason", rarity:2, type:"normal" },
{ id:413, name:"Blackbeard", rarity:2, type:"normal" },
{ id:414, name:"Mephistopheles", rarity:2, type:"normal" },
{ id:415, name:"Phantom of the Opera", rarity:2, type:"normal" },
{ id:416, name:"Mata Hari", rarity:2, type:"normal" },
{ id:417, name:"Caligula", rarity:2, type:"normal" },
{ id:418, name:"Romulus", rarity:2, type:"normal" },
{ id:419, name:"Gilles (Caster)", rarity:2, type:"normal" }
];

const chances = [
    {rarity:9, chance:0.0001},
    {rarity:8, chance:0.001},
    {rarity:7, chance:0.01},
    {rarity:6, chance:0.1},
    {rarity:5, chance:1},
    {rarity:4, chance:5},
    {rarity:3, chance:30},
    {rarity:2, chance:63.8889}
];

const highPityConfig = {
    7: { base: 0.01, cap: 0.1 },
    8: { base: 0.001, cap: 0.01 },
    9: { base: 0.0001, cap: 0.001 }
};

/* ================= SAVE ================= */
let crystals = parseInt(localStorage.getItem("crystals")) || 0;
let collection = JSON.parse(localStorage.getItem("collection")) || {};
let isInvoking = false;
let skillGuaranteedFive = JSON.parse(localStorage.getItem("skillGuaranteedFive")) || false;
let skillGuaranteedSix = JSON.parse(localStorage.getItem("skillGuaranteedSix")) || false;

/* ================= === NEW : PITY SYSTEM ================= */

let pity = JSON.parse(localStorage.getItem("pity")) || {
    five: 0,
    six: 0,
    seven: 0,
    eight: 0,
    nine: 0
};

/* ================= === NEW : EVENT SYSTEM ================= */

let activeEvent = JSON.parse(localStorage.getItem("activeEvent")) || null;

/* ================= UI ================= */
const hud = document.getElementById("hud");
const resultDiv = document.getElementById("result");
const collectionDiv = document.getElementById("collection");
const grid = document.getElementById("grid");

/* ================= MINI GAME : COLOR ================= */
let level = 1;
let score = 0;

document.getElementById("play").onclick = startColorGame;

function startColorGame(){
    level = 1;
    score = 0;
    generateLevel();
}

function randomColor(){
    return {
        r: Math.floor(Math.random()*200)+30,
        g: Math.floor(Math.random()*200)+30,
        b: Math.floor(Math.random()*200)+30
    };
}
function css(c){ return `rgb(${c.r},${c.g},${c.b})`; }

function generateLevel(){
    grid.innerHTML = "";
    const size = 2 + Math.floor(level / 2);
    const total = size * size;
    const diff = Math.max(60 - level * 2, 5);

    const base = randomColor();
    const odd = {
        r: Math.min(base.r + diff, 255),
        g: Math.min(base.g + diff, 255),
        b: Math.min(base.b + diff, 255)
    };
    const oddIndex = Math.floor(Math.random() * total);
    let locked = false;

    grid.style.gridTemplateColumns = `repeat(${size}, 1fr)`;

    for(let i=0;i<total;i++){
        const cell = document.createElement("div");
        cell.className = "cell";
        cell.style.background = i===oddIndex ? css(odd) : css(base);

        cell.onclick = ()=>{
            if(locked) return;
            if(i===oddIndex){
                score += level * 10;
                level++;
                    if(level >= 25 && !skillGuaranteedFive){
                        skillGuaranteedFive = true;
                        alert("🔥 SKILL BOOST 🔥\nProchaine invocation garantie 5★ !");
                        save();
                    }
                    if(level >= 30 && !skillGuaranteedSix){
                        skillGuaranteedSix = true;
                        alert("🔥 SKILL BOOST 🔥\nProchaine invocation garantie 6★ !");
                        save();
                    }
                generateLevel();
            } else {
                locked = true;
                cell.classList.add("wrong");
                grid.children[oddIndex].classList.add("correct");
                setTimeout(endColorGame, 800);
            }
        };
        grid.appendChild(cell);
    }
    updateHUD();
}

function endColorGame(){
    let gain = Math.floor(score/100);

    // === NEW : EVENT MULTIPLIER ===
    if(activeEvent?.type === "crystal_x2") gain *= 2;
    if(activeEvent?.type === "crystal_x3") gain *= 3;
    if(activeEvent?.type === "crystal_x10") gain *= 10;

    crystals += gain;
    activeEvent = null;
    save();

    alert(`Fin de partie\nScore : ${score}\nCristaux gagnés : +${gain}`);
    grid.innerHTML = "";
    updateHUD();
}

/* ================= EVENT SYSTEM ================= */

function rollEvent(){
    const r = Math.random() * 100;

    // 🌟 GOLDEN PULL – ultra rare
    if(r < 0.1){
        activeEvent = {
            guaranteed5Plus: true,
            boostUntil: Date.now() + 2 * 60 * 1000
        };
        alert("🌟 EVENT ULTRA RARE 🌟\nProchaine invocation : uniquement des 5★+\nBoost 5★+ pendant 2 minutes !");
    }

    // 🔮 BOOST GLOBAL 5 %
    else if(r < 5){
        activeEvent = {
            boostUntil: Date.now() + 2 * 60 * 1000,
            boostTable: {
                5: 1.5,
                6: 1.25,
                7: 1.10,
                8: 1.05,
                9: 1
            }
        };
        alert("✨ EVENT BOOST ✨\nProbabilités augmentées pendant 2 minutes !");
    }

    // 💎 events cristaux inchangés
    else if(r < 1){
        activeEvent = { type:"crystal_x10" };
        alert("💎 EVENT HYPER RARE 💎\nCristaux x10 !");
    }
    else if(r < 6){
        activeEvent = { type:"crystal_x3" };
        alert("💠 Event ! Cristaux x3");
    }

    else if(r < 16){
        activeEvent = { type:"crystal_x2" };
        alert("💠 Event ! Cristaux x2");
    }
}


function isBoostActive(){
    return activeEvent?.boostUntil && Date.now() < activeEvent.boostUntil;
}

/* ================= GACHA ================= */
function rollRarity(minRarity = 2){

    // === 1️⃣ SKILL GUARANTEE PRIORITÉ MAX ===
    if(skillGuaranteedFive){
        skillGuaranteedFive = false;
        save();
        return 5;
    }
    if(skillGuaranteedSix){
        skillGuaranteedSix = false;
        save();
        return 6;
    }

    // === 2️⃣ HARD PITY ===
    if(pity.six >= 100){
        return 6;
    }

    if(pity.five >= 50){
        return 5;
    }

    // === 3️⃣ CALCUL NORMAL DES CHANCES ===
    let modifiedChances = chances.map(c => {

        let chance = c.chance;

        // === PITY 7 / 8 / 9 AVEC CAP ===
        if(c.rarity >= 7){
            const cfg = highPityConfig[c.rarity];
            const pityCount = pity[
                c.rarity === 7 ? "seven" :
                c.rarity === 8 ? "eight" : "nine"
            ];

            const increment = cfg.base * pityCount;
            chance = Math.min(cfg.base + increment, cfg.cap);
        }

        return { rarity: c.rarity, chance };
    });

    // === BOOST TEMPORAIRE ===
    if(isBoostActive()){
        modifiedChances = modifiedChances.map(c=>{
            let boost = 1;

            if(activeEvent.boostTable && activeEvent.boostTable[c.rarity]){
                boost = activeEvent.boostTable[c.rarity];
            }
            else if(c.rarity >= 5){
                boost = 1.5;
            }

            return {
                rarity: c.rarity,
                chance: c.chance * boost
            };
        });
    }

    // === FILTRE GOLDEN PULL ===
    modifiedChances = modifiedChances.filter(c => c.rarity >= minRarity);

    const total = modifiedChances.reduce((s,c)=>s+c.chance,0);
    let r = Math.random() * total;
    let sum = 0;

    for(let c of modifiedChances){
        sum += c.chance;
        if(r <= sum) return c.rarity;
    }

    return minRarity;
}
function draw(){
    const rarity = rollRarity();
    const pool = characters.filter(c => c.rarity === rarity);
    return pool[Math.floor(Math.random()*pool.length)];
}

/* ================= INVOCATION ================= */

function invoke(times){

    if(isInvoking) return;

    // === EVENT PEUT SE DÉCLENCHER ===
    rollEvent();

    // === GOLDEN PULL : décision UNE FOIS ===
    const isGolden = activeEvent?.guaranteed5Plus === true;

    // Le garanti est consommé immédiatement
    if(isGolden){
        delete activeEvent.guaranteed5Plus;
    }

    // === PITY = +1 PAR INVOCATION ===
    pity.five++;
    pity.six++;
    pity.seven++;
    pity.eight++;
    pity.nine++;

    isInvoking = true;
    toggleDrawButtons(true);

    resultDiv.innerHTML = "";
    let queue = [];

    for(let i = 0; i < times; i++){

        // === TIRAGE AVEC FILTRE GOLDEN SI ACTIF ===
        const rarity = rollRarity(isGolden ? 5 : 2);
        const pool = characters.filter(c => c.rarity === rarity);
        const char = pool[Math.floor(Math.random() * pool.length)];

        // === RESET PITY SUR DROP ===
        if(char.rarity === 9){
            pity.nine = 0;
            pity.eight = 0;
        }
        else if(char.rarity === 8){
            pity.eight = 0;
            pity.nine = 0;
        }
        else if(char.rarity === 7){
            pity.seven = 0;
        }
        else if(char.rarity >= 6){
            pity.six = 0;
            pity.five = 0;
        }
        else if(char.rarity === 5){
            pity.five = 0;
        }

        collection[char.id] = (collection[char.id] || 0) + 1;
        queue.push(char);
    }

    function next(){
        if(queue.length === 0){
            renderCollection();
            save();
            isInvoking = false;
            toggleDrawButtons(false);
            return;
        }

        const char = queue.shift();
        playAnimation(char.rarity, ()=>{
            if(char.rarity >= 6){
                showCenterCard(char, ()=>{
                    addResultCard(char);
                    next();
                });
            } else {
                addResultCard(char);
                next();
            }
        });
    }

    next();
}

function addResultCard(char){
    const div = document.createElement("div");
    div.className = `card star${char.rarity} ${char.type||""}`;
    div.innerHTML = `${"★".repeat(char.rarity)}<br>${char.name}`;
    resultDiv.appendChild(div);
}

/* ================= FLASH ================= */

function playAnimation(rarity, callback){
    document.body.className = "";
    if(rarity >= 5){
        document.body.classList.add(`flash${rarity}`);
    }
    setTimeout(()=>{
        document.body.className = "";
        callback?.();
    }, 700);
}

/* ================= BOUTONS ================= */
document.getElementById("draw1").onclick = ()=>{
    if(crystals < 3) return alert("Pas assez de cristaux");
    crystals -= 3;
    invoke(1);
    updateHUD();
};

document.getElementById("draw10").onclick = ()=>{
    if(crystals < 30) return alert("Pas assez de cristaux");
    crystals -= 30;
    invoke(11);
    updateHUD();
};

function toggleDrawButtons(disabled){
    document.getElementById("draw1").disabled = disabled;
    document.getElementById("draw10").disabled = disabled;
}

function showCenterCard(char, onComplete, forceUnknown = false){
    const wrapper = document.createElement("div");
    wrapper.className = "center-card";

    const inner = document.createElement("div");
    inner.className = "card-inner";

    const front = document.createElement("div");
    front.className = "card-front";
    front.innerHTML = "???";

    const back = document.createElement("div");
    back.className = `card-back star${char.rarity}`;

    const chance = chances.find(c=>c.rarity===char.rarity)?.chance || 0;
    back.innerHTML = `
        ${"★".repeat(char.rarity)}<br>
        ${forceUnknown ? "?????" : char.name}<br>
        ${chance ? `1 / ${(100/chance).toFixed(0)}` : ""}
    `;

    inner.append(front, back);
    wrapper.append(inner);
    document.body.appendChild(wrapper);

    // flip
    setTimeout(()=>inner.classList.add("flipped"), 200);

    // === MODE TIRAGE (auto close) ===
    if(typeof onComplete === "function"){
        setTimeout(()=>{
            document.body.removeChild(wrapper);
            onComplete();
        }, 2500);
    }

    // === MODE BIBLIOTHÈQUE (clic pour fermer) ===
    else {
        wrapper.onclick = ()=>{
            document.body.removeChild(wrapper);
        };
    }
}

document.getElementById("reset").onclick = ()=>{ if(!confirm("Réinitialiser la partie ?")) return; crystals = 0; score = 0; level = 1; collection = {}; resultDiv.innerHTML = ""; grid.innerHTML = ""; save(); renderCollection(); updateHUD(); };

/* ================= COLLECTION ================= */

function renderCollection(){
    collectionDiv.innerHTML = "";
    characters.forEach(c=>{
        const owned = collection[c.id];
        const div = document.createElement("div");
        div.className = `card star${c.rarity} ${owned?"":"locked"}`;
        div.innerHTML = `${"★".repeat(c.rarity)}<br>${owned?c.name:"?????"}`;
        div.onclick = ()=>showCenterCard(c, null, !owned);
        collectionDiv.appendChild(div);
    });
}

/* ================= SAVE / HUD ================= */

function save(){
    localStorage.setItem("crystals", crystals);
    localStorage.setItem("collection", JSON.stringify(collection));
    localStorage.setItem("pity", JSON.stringify(pity));
    localStorage.setItem("activeEvent", JSON.stringify(activeEvent));
}

function updateHUD(){
    hud.innerHTML = `
        Cristaux : ${crystals}<br>
        Niveau : ${level}<br>
        Score : ${score}<br>
        Pity 5★ : ${pity.five}/50<br>
        Pity 6★ : ${pity.six}/100<br>
        Obtenus : ${Object.keys(collection).length}/${characters.length}
    `;
}

/* ================= INIT ================= */

updateHUD();
renderCollection();
